import {React, useState} from 'react';
import { Image, Form, Button, Modal, Container, Row, Col} from 'react-bootstrap';
import axios from 'axios'
import { Link } from 'react-router-dom';

import 'bootstrap/dist/css/bootstrap.min.css'

// Get search query terms from user
export default function Home() {
    const [image, setImage] = useState();
    const [imageDisp, setImageDisp] = useState();
    const [imageUpscaled, setImageUpscaled] = useState();
    const [imageUpscaledDisp, setImageUpscaledDisp] = useState();

    const [show, setShow] = useState(false);
    const [errorMessage, setErrorMessage] = useState('');

    const uploadImage = event => {
        setImage(event.target.files[0])
        console.log(event.target.files[0])
        setImageDisp(URL.createObjectURL(event.target.files[0]))

    }

    const handleClick = event => {
        if (image == null)
        {
            setErrorMessage("Please upload an image. Will only accept .png, .jpg, .jpeg and .bmp files");
            setShow(true);
        }
        else 
        {
            console.log(image)
            fetchRequest(setImageUpscaled, image);
        }

    }

    const handleClose = () =>{
        setShow(false);
    } 

    return (
        <div className = "register">
            <h2>Upload Image</h2>
            <Form>
                <Container>
                    <Row>
                        <Col>
                            <div className = "Input" style={{height: '300px', width: '300px'}}>
                                <Form.Group className="upload" controlId="upload">
                                <Form.File onChange={(event) => uploadImage(event)} accept="image/*" size="1280000"/>
                                <Image src={imageDisp} thumbnail fuild/>
                                </Form.Group>
                            </div>
                        </Col>
                        
                        <Col>
                            <Button variant="primary" onClick={handleClick}>Upscale</Button>
                            <div className = "Output" style={{height: '300px', width: '300px'}}>
                                <Form.Group className="upscaled" controlId="upscaled">
                                <Image src={imageUpscaled}/>
                                </Form.Group>
                            </div>
                        </Col>
                    </Row>
                </Container>
            </Form>

            <div className = "error">
                <Modal show={show} onHide={handleClose}>
                <Modal.Header closeButton>
                    <Modal.Title>Opps something went wrong :(</Modal.Title>
                </Modal.Header>
                <Modal.Body>{errorMessage}</Modal.Body>
                </Modal>
            </div>
        </div>
    );
}

function fetchRequest(setImageUpscaled, imageBuf){
    var formData = new FormData();
    formData.append('image', imageBuf, imageBuf.name)
    console.log(formData)

    axios.post('http://192.168.20.33:5000/upload', formData)
    
    /*
    fetch('http://192.168.20.33:5000/upload',
    {
        method: 'POST',
        headers: {
            'Accept': 'application/json',
            'Access-Control-Allow-Origin': '*',
            'Content-Type': 'application/json'
        },
        body: form
    }) 
    .then( (response) => {
        if (response.ok) {
            return response.json();
        }
        throw new Error("Network response was not ok.");
    })
    .then( (rsp) => {
        let ImageUpscaled = rsp.toString('base64');
        setImageUpscaled(ImageUpscaled);
    })
    .catch(function(error) {
        console.log("There has been a problem with your fetch operation: ",error.message);
    });
    */
}