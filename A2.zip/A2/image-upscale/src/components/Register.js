import { React, useState } from 'react';
import { Button, Form, InputGroup} from 'react-bootstrap';
import { Link } from 'react-router-dom';
import 'bootstrap/dist/css/bootstrap.min.css'

// Get search query terms from user
export default function Register() {
    const [firstName, setFirstName] = useState();
    const [lastName, setLastName] = useState();
    const [username, setUsername] = useState();
    const [password, setPassword] = useState();
    const [validated, setValidated] = useState(false);

    const handleClick = (event) => {
        const form = event.currentTarget;
        if (form.checkValidity() === false) {
          //event.preventDefault();
          //event.stopPropagation();
        }
        setValidated(true);
    };

    return (
        <div className = "register">
            <h2>Register</h2>
            <Form noValidate validated={validated}>
                <Form.Group  controlId="FirstNameValidation">
                    <Form.Label>First Name</Form.Label>
                    <InputGroup hasValidation>
                        <Form.Control type="text" placeholder="First Name" onChange={(event) => { setFirstName(event.target.value)}} required/>
                        <Form.Control.Feedback type="invalid">
                        Please enter your first name.
                        </Form.Control.Feedback>
                    </InputGroup>
                </Form.Group>

                <Form.Group  controlId="LastNameValidation">
                    <Form.Label>Last Name</Form.Label>
                    <InputGroup hasValidation>
                        <Form.Control type="text" placeholder="Last Name" onChange={(event) => { setLastName(event.target.value)}} required/>
                        <Form.Control.Feedback type="invalid">
                        Please enter your last name.
                        </Form.Control.Feedback>
                    </InputGroup>
                </Form.Group>

                <Form.Group  controlId="UsernameValidation">
                    <Form.Label>Username</Form.Label>
                    <InputGroup hasValidation>
                        <Form.Control type="text" placeholder="Username" onChange={(event) => { setUsername(event.target.value)}} required/>
                        <Form.Control.Feedback type="invalid">
                        Please enter a username.
                        </Form.Control.Feedback>
                    </InputGroup>
                </Form.Group>

                <Form.Group  controlId="PasswordValidation">
                    <Form.Label>Password</Form.Label>
                    <InputGroup hasValidation>
                        <Form.Control type="text" placeholder="Password" onChange={(event) => { setPassword(event.target.value)}} required/>
                        <Form.Control.Feedback type="invalid">
                        Please enter a password.
                        </Form.Control.Feedback>
                    </InputGroup>
                </Form.Group>

                <Button variant="light" onClick={handleClick}>Register</Button>
                
                <Link to="/login" className="btn btn-link">Cancel</Link>

            </Form>
        </div>
    );
}

function fetchRequest(firstname, lastname, username, password){
    fetch('http://192.168.20.33:5000/login',
    {
        method: 'POST',
        headers: {
            'Accept': 'application/json',
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({'firstname': firstname, 'lastname': lastname, 'username': username, 'password': password})
    }) 
    .then( (response) => {
        if (response.ok) {
            return response.json();
        }
        throw new Error("Network response was not ok.");
    })
    .then( (rsp) => {
        let ImageUpscaled = rsp.toString('base64');
    })
    .catch(function(error) {
        console.log("There has been a problem with your fetch operation: ",error.message);
    });
}