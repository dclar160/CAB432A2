import { React, useState } from 'react';
import { Button, Form, Modal, InputGroup, Image} from 'react-bootstrap';
import { Link } from 'react-router-dom';
import 'bootstrap/dist/css/bootstrap.min.css'
import PropTypes from 'prop-types';

async function loginUser(credentials) {
    return fetch('http://localhost:8080/login', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json'
      },
      body: JSON.stringify(credentials)
    })
      .then(data => data.json())
   }

// Get search query terms from user
export default function Login({ setToken }) {
    const [username, setUsername] = useState('');
    const [password, setPassword] = useState('');

    const [show, setShow] = useState(false);
    const [errorMessage, setErrorMessage] = useState('');

    const [validated, setValidated] = useState(false);

    const handleClick = async (event) => {
        const form = event.currentTarget;
        // Check for user input
        if (form.checkValidity() === false) {
          //event.preventDefault();
          //event.stopPropagation();
        }
        // Check for correct credentials
        else if (username || password == '1')
        {
            setValidated(true);
            setErrorMessage("Username or password is incorrect. Please try again.");
            setShow(true);
        }
        else
        {
            setValidated(true);
            event.preventDefault();
            const token = await loginUser({
              username,
              password
            });
            setToken(token);
        }
    }

    const handleClose = () =>{
        setShow(false);
    } 

    return (
        <div className = "login">
            <Image src="https://www.gamerevolution.com/assets/uploads/2021/01/Easy-AI-upscale-1080p-4K.png" roundedCircle/>
            <h2>Login</h2>
            <Form noValidate validated={validated}>
                <Form.Group  controlId="UsernameValidation">
                    <Form.Label>Username</Form.Label>
                    <InputGroup hasValidation>
                        <Form.Control type="text" placeholder="Username" onChange={(event) => { setUsername(event.target.value)}} required/>
                        <Form.Control.Feedback type="invalid">
                        Please enter a username.
                        </Form.Control.Feedback>
                    </InputGroup>
                </Form.Group>

                <Form.Group  controlId="PasswordValidation">
                    <Form.Label>Password</Form.Label>
                    <InputGroup hasValidation>
                        <Form.Control type="text" placeholder="Password" onChange={(event) => { setPassword(event.target.value)}} required/>
                        <Form.Control.Feedback type="invalid">
                        Please enter a password.
                        </Form.Control.Feedback>
                    </InputGroup>
                </Form.Group>

                <Button variant="light" onClick={handleClick}>Login</Button>
                
                <Link to="/register" className="btn btn-link">Register</Link>
                
            </Form>

            <div className = "error">
                <Modal show={show} onHide={handleClose}>
                <Modal.Header closeButton>
                    <Modal.Title>Opps something went wrong :(</Modal.Title>
                </Modal.Header>
                <Modal.Body>{errorMessage}</Modal.Body>
                </Modal>
            </div>
        </div>
    );
}

Login.propTypes = {
    setToken: PropTypes.func.isRequired
}

function fetchRequest(username, password){
    fetch('http://192.168.20.33:5000/login',
    {
        method: 'POST',
        headers: {
            'Accept': 'application/json',
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({'username': username, 'password': password})
    }) 
    .then( (response) => {
        if (response.ok) {
            return response.json();
        }
        throw new Error("Network response was not ok.");
    })
    .then( (rsp) => {
        let ImageUpscaled = rsp.toString('base64');
    })
    .catch(function(error) {
        console.log("There has been a problem with your fetch operation: ",error.message);
    });
}



