const TOKEN_KEY = 'test1234';

export const checkLogin = () => {
    if (localStorage.getItem(TOKEN_KEY)) {
        return true;
    }

    return false;
}