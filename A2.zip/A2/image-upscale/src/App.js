import './App.css';
import { BrowserRouter, Route, Switch, Redirect } from 'react-router-dom';  
import Home from './components/Home.js';
import Login from './components/Login.js';
import Register from './components/Register.js';
import PrivateRoute from './components/PrivateRoute';
import {React, useState} from 'react';


function App() {
  const [token, setToken] = useState();

  return (
    <div className="App-header">
      <h1>Image Upscaler</h1>
      <BrowserRouter>
        <Switch>
          <Route path="/home" component={Home}/>
          <Route path="/login" component={Login}/>
          <Route path="/register" component={Register}/>
          <PrivateRoute path="/" component={Home}/>
          <Redirect from="*" to="/" />
        </Switch>
      </BrowserRouter>
    </div>
  );
}

export default App;
